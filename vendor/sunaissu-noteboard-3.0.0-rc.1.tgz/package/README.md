Release candidate details: [RELEASE.txt](./RELEASE.txt). This candidate has not been published.

# @sunaissu/noteboard

> A highly customizable, responsive React whiteboard canvas for drawing, diagramming, and real-time collaboration.

[![npm version](https://img.shields.io/npm/v/@sunaissu/noteboard)](https://www.npmjs.com/package/@sunaissu/noteboard)
[![license](https://img.shields.io/npm/l/@sunaissu/noteboard)](./LICENSE)

---

## 🚀 Features

- **Rich Toolset** — Draw shapes (rectangles, ellipses, diamonds, triangles, stars/polygons), lines, auto-connecting arrows, text, freehand pen, and images.
- **Advanced Elements** — Built-in support for Sticky Notes and Callouts.
- **Persistent Connector Snapping** — Line and arrow endpoints snap anywhere along the visible outline of nearby shapes. Attachments follow the shape when it moves, resizes, or rotates and persist in saved or collaborative boards.
- **Smart Grouping & Locking** — Group shapes, lock elements in place, and control z-order.
- **Collapsible Properties Panel** — The entire panel can be collapsed to a thin header bar. Individual property sections (Appearance, Drop Shadow, Text, Line/Arrow, Pen, Shape) also collapse independently via chevron toggles.
- **Snap-to-Grid & Alignment Guides** — Dot-grid overlay, snap-to-grid, and smart alignment tools for precise layouts.
- **Undo / Redo Toolbar Buttons** — ↩ / ↪ buttons surface the full undo/redo history directly in the toolbar strip.
- **Right-Click Context Menu** — Copy, Paste, Duplicate, Bring Forward / Send Backward, Bring to Front / Send to Back, Select All, and Delete — all accessible via right-click anywhere on the canvas.
- **Keyboard Shortcut Cheatsheet** — Press `?` (or the `?` button in the ☰ menu) to open a modal listing every keyboard shortcut organized by category.
- **Board Management** — Export as PNG/JPEG, import/export state as JSON, toggle grid visibility, and clear the canvas with a confirmation prompt.
- **Theme Support** — Automatic system detection, explicit light/dark modes, and semantic color overrides.
- **Focus Ring** — The canvas shows a visible purple focus ring when it receives keyboard focus, aiding accessibility.
- **Read-Only Mode** — Lock the board to view-only with a single prop or toggle.
- **Multiplayer Ready** — Completely server-agnostic. Integrates with WebSockets or CRDTs via controlled `elements` + `onElementsChange` props.
- **Lightweight Previews** — `NoteboardPreview` renders a static, zero-interaction board thumbnail using the same rendering engine.

---

## 📦 Installation

```bash
npm install @sunaissu/noteboard
# or
yarn add @sunaissu/noteboard
# or
pnpm add @sunaissu/noteboard
```

---

## 💻 Quick Start

```tsx
import React, { useState } from 'react';
import { Noteboard } from '@sunaissu/noteboard';
import type { NoteboardElement } from '@sunaissu/noteboard';

export default function App() {
  const [elements, setElements] = useState<NoteboardElement[]>([]);

  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <Noteboard
        elements={elements}
        onElementsChange={setElements}
        defaultTheme="system"
        brandColors={{ primary: '#7c5cff', secondary: '#22a06b' }}
      />
    </div>
  );
}
```

---

## 🛠 Props API

| Prop | Type | Default | Description |
|---|---|---|---|
| `theme` | `'system' \| 'light' \| 'dark' \| NoteboardTheme` | `undefined` | Controlled theme mode. A full `NoteboardTheme` object remains supported as a legacy override. |
| `defaultTheme` | `'system' \| 'light' \| 'dark'` | `'system'` | Initial mode when `theme` is uncontrolled. |
| `brandColors` | `{ primary?: string; secondary?: string }` | `undefined` | Adapts active tools, focus, selection, badges, and supporting accents to the host app while preserving every theme mode. |
| `themeOverrides` | `Partial<NoteboardTheme>` | `undefined` | Change individual colors without disabling mode switching. |
| `onThemeChange` | `(theme: NoteboardThemeMode) => void` | `undefined` | Fires when Automatic, Light, or Dark is selected in board settings. Use it with a controlled `theme`. |
| `initialElements` | `NoteboardElement[]` | `[]` | Seed elements on first mount. Uncontrolled — ignored after mount. |
| `initialViewport` | `NoteboardViewport` | `undefined` | Seed pan & zoom on first mount (e.g. from a saved `NoteboardSession`). |
| `viewport` | `NoteboardViewport` | `undefined` | Fully controlled pan and zoom state. Use with `onViewportChange` for persistence or collaboration. |
| `elements` | `NoteboardElement[]` | `undefined` | Fully controlled elements array. Use alongside `onElementsChange` for real-time collaboration. |
| `onElementsChange` | `(elements: NoteboardElement[], previous?: NoteboardElement[]) => void` | `undefined` | Fires after every local draw, edit, move, or delete. Forward both arguments when wrapping a collaborative binding. |
| `onViewportChange` | `(viewport: NoteboardViewport) => void` | `undefined` | Fires whenever the user pans or zooms. Use to persist or broadcast the viewport. |
| `readOnly` | `boolean` | `undefined` | Controlled read-only mode — hides the toolbar, disables all editing interactions. |
| `defaultReadOnly` | `boolean` | `false` | Initial read-only state (uncontrolled). |
| `onReadOnlyChange` | `(readOnly: boolean) => void` | `undefined` | Deprecated compatibility prop. Control `readOnly` from the host application. |
| `toolbarPosition` | `'top' \| 'bottom' \| 'left' \| 'right'` | `'bottom'` | Position of the main toolbar. |
| `propertiesPosition` | `'top' \| 'bottom' \| 'left' \| 'right'` | `'left'` | Position of the properties panel. |
| `slots` | `ToolSlot[]` | `DEFAULT_SLOTS` | Customize which tools appear in the toolbar and their order. |
| `activeTool` | `Tool` | `undefined` | Controlled active tool. |
| `onToolSelect` | `(tool: Tool) => void` | `undefined` | Fires when the user switches tools. |
| `onSave` | `(session: NoteboardSession) => void` | `undefined` | Adds a Save button to the ☰ menu. Called with a full serialized snapshot. |
| `threadId` | `string` | `undefined` | Identifies the room/thread (used with collaboration integrations). |
| `boardId` | `string` | `undefined` | Identifies the board instance. |

---

## 🔧 Imperative API (`ref`)

Pass a `ref` to access the board imperatively:

```tsx
import { useRef } from 'react';
import { Noteboard } from '@sunaissu/noteboard';
import type { NoteboardRef } from '@sunaissu/noteboard';

function App() {
  const ref = useRef<NoteboardRef>(null);

  return (
    <>
      <Noteboard ref={ref} />
      <button onClick={() => console.log(ref.current?.getElements())}>Log elements</button>
      <button onClick={() => ref.current?.setElements([])}>Clear board</button>
      <button onClick={() => {
        const url = ref.current?.exportImage('png');
        window.open(url);
      }}>Export PNG</button>
    </>
  );
}
```

| Method | Signature | Description |
|---|---|---|
| `getElements()` | `() => NoteboardElement[]` | Returns the current live elements array. |
| `setElements()` | `(elements: NoteboardElement[]) => void` | Replaces elements through history and honors read-only mode. |
| `setViewport()` | `(viewport: NoteboardViewport) => void` | Imperatively pans and zooms the board. Zoom is clamped to the supported range. |
| `getSession()` | `() => NoteboardSession` | Returns a full DB-ready board snapshot. |
| `exportImage()` | `(format?: 'png' \| 'jpeg', options?: BoardImageOptions) => string` | Renders board content as a data URL; images must already be loaded. |
| `exportImageAsync()` | `(format?: 'png' \| 'jpeg', options?: BoardImageOptions) => Promise<string>` | Waits for images, then exports board content. |
| `focusElements()` | `(ids: string[]) => void` | Selects matching objects and fits them into view. |

---

## 🧪 Playground

The Vite playground imports Noteboard directly from `src` and exercises toolbar placement, themes, read-only mode, viewport presets, and export APIs:

```bash
npm install
npm --prefix playground install
npm run playground
```

Use `npm run playground:build` for a production playground build.

---

## 📡 Viewport Sync (`onViewportChange`)

Use `onViewportChange` to track pan & zoom externally — useful for persisting the viewport or syncing it across clients:

```tsx
import { useState } from 'react';
import { Noteboard } from '@sunaissu/noteboard';
import type { NoteboardViewport } from '@sunaissu/noteboard';

function App() {
  const [viewport, setViewport] = useState<NoteboardViewport>({ panX: 0, panY: 0, zoom: 1 });

  return (
    <>
      <p>Zoom: {Math.round(viewport.zoom * 100)}%</p>
      <Noteboard onViewportChange={setViewport} />
    </>
  );
}
```

---

## 🤝 Multiplayer & Collaboration

Noteboard is server-agnostic. For concurrent editing, install Yjs and connect the optional adapter to any Yjs provider:

```tsx
import * as Y from 'yjs';
import { Noteboard } from '@sunaissu/noteboard';
import { useYjsNoteboard } from '@sunaissu/noteboard/yjs';

const document = new Y.Doc();

export function MultiplayerBoard() {
  const binding = useYjsNoteboard(document);
  return (
    <Noteboard
      elements={binding.elements}
      onElementsChange={binding.onElementsChange}
      history={binding.history}
      viewport={binding.viewport}
      onViewportChange={binding.onViewportChange}
    />
  );
}
```

Attach `document` to a provider such as Hocuspocus or `y-websocket`. The adapter stores elements in independent `Y.Map` values and labels in `Y.Text`. Pass `binding.history` to scope undo to the current editor. Navigation stays local by default; set `shareViewport: true` only for shared navigation. Z-order remains a separate `Y.Array`. The adapter applies local insertion, deletion and move changes without replacing untouched order entries. A stale append preserves peer ordering, and undo tracks local changes. Simultaneous moves of the same object follow Yjs conflict ordering. Authentication, persistence, and transport belong to the host.

Connector `startBinding` and `endBinding` metadata is part of each line or arrow element, so the adapter and normal JSON session serialization preserve snapped connections automatically.

---

## 🖼️ Lightweight Previews

Use `NoteboardPreview` to render a read-only, static snapshot without mounting the full interactive canvas:

```tsx
import { NoteboardPreview } from '@sunaissu/noteboard';
import type { NoteboardElement } from '@sunaissu/noteboard';

export function DashboardCard({ elements }: { elements: NoteboardElement[] }) {
  return (
    <div className="card">
      <h3>My Board</h3>
      <NoteboardPreview
        elements={elements}
        height={120}
        style={{ borderRadius: '6px', border: '1px solid #ddd' }}
      />
    </div>
  );
}
```

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl + Z` | Undo |
| `Ctrl + Shift + Z` | Redo |
| `Ctrl + C` | Copy selected |
| `Ctrl + V` | Paste |
| `Ctrl + D` | Duplicate selected |
| `Ctrl + A` | Select all |
| `Ctrl + G` | Group selected |
| `Ctrl + Shift + G` | Ungroup |
| `Delete` | Delete selected |
| `Escape` | Deselect / finish text edit |
| `]` / `[` | Bring forward / send backward |
| `Ctrl + ]` / `Ctrl + [` | Bring to front / send to back |
| `Ctrl + Scroll` | Zoom in / out |
| `Scroll` | Pan canvas |
| `G` | Toggle grid & snap |
| `?` | Open keyboard shortcut cheatsheet |

> Press `?` inside the board at any time to see the full cheatsheet modal.

---

## 📋 Changelog

See [CHANGELOG.md](./CHANGELOG.md) for a full list of changes across versions.

---

## 📜 License

MIT License. See [LICENSE](./LICENSE) for details.

## 3.0.0 release candidate collaboration migration

This working tree changes the shared text schema. Before updating an existing collaborative deployment, back up the Yjs document, disconnect old clients, run `migrateNoteboardText(document)` from `@sunaissu/noteboard/yjs` on the authoritative document, persist it, and reconnect only updated clients. Do not let disconnected old clients independently migrate or overwrite the same labels. Plain JSON board snapshots still contain ordinary text strings.

The adapter initializes content only once per mounted binding. For a provider-backed document, seed initial content on the server after loading persisted state; mounting clients should not independently seed an empty document before synchronization.

## Editable templates and playground

`createBoardTemplate` returns fresh editable objects for `flowchart`, `planning`, and `brainstorm`. Each call generates new object/group IDs and internal connector bindings. Insert through the ref to record one undo action:

```tsx
import { createBoardTemplate } from '@sunaissu/noteboard';

const board = boardRef.current;
if (board) {
  const added = createBoardTemplate('planning', { x: 100, y: 80 });
  board.setElements([...board.getElements(), ...added]);
  board.focusElements(added.map(element => element.id));
}
```

The playground now shares the calculator/editor page design: a responsive canvas and inspector, theme/brand controls, template insertion, fit/reset, PNG and session JSON exports, and a JSON preview with merge/replace choices. Merge assigns new IDs and remaps connections; import and reset can be undone. Read-only mode disables changes. Changes stay in memory until exported. Saved custom template catalogs and template version migration remain planned.

## Navigation, exports, and image limits

Settings includes an object search, board overview, and up to 20 viewpoints retained for the mounted session. `ref.current.focusElements(ids)` selects objects and fits them in view.

`exportImage(format, options)` renders board content independently of the viewport, grid, and selection overlays. Use `exportImageAsync` when images may still be loading. Both accept `selectedIds`, `padding`, `scale`, and `background`; PNG can be transparent, while JPEG gets an opaque background. Output is capped at 8192 pixels per edge and 16 million pixels overall.

Uploads and pasted images accept PNG, JPEG, GIF, and WebP. `maxImageBytes` defaults to 5 MiB and can lower that limit; `maxImagePixels` defaults to 16 million decoded pixels. The host must also enforce its storage limits. Imports, text edits, and imperative element replacements participate in history.

See [the implementation review](./implementation-review.txt) for verification and [the feature backlog](./feature-backlog.txt) for all 26 feature contracts, dependencies and acceptance checks. OPEN and PARTIAL items remain unfinished. No release has been published from this working tree.

## Development checks

Run `npm test`, `npm run playground:build`, and `npm pack --dry-run --json` before release. The GitHub Actions workflow is configured to test the package on Node 18, 22 and 24, build the playground on Node 22/24, and audit both dependency trees. Browser checks remain a separate local step documented in the implementation review. The workflow has not been run on GitHub as part of this local review.

## Properties layout and scrolling

Top and bottom properties use category tabs and a horizontally scrollable row of controls, capped at 220 CSS pixels. Side panels retain the vertically scrollable inspector. Arrow keys, Home and End switch categories; Tab reaches their controls. Wheel input over horizontal properties moves the control strip. Toolbar and zoom placement follow the measured panel size, including collapse and narrow layouts.

Wheel gestures over the canvas pan the board; Shift pans horizontally, and Ctrl/Command zooms around the cursor. Inspectors and text inputs scroll locally. Reaching an inspector edge does not scroll the surrounding page, and wheel input outside the board keeps normal page scrolling. Native wheel cancellation prevents browser scrolling alongside React canvas updates. Line/page wheel units are normalized; touch/stylus navigation remains separate work.

## Review safeguards

Snapshot images accept only PNG, JPEG, GIF and WebP base64 data URLs, with valid base64 syntax and an 8 MiB URL-text limit. Rendering rejects decoded images above 16 million pixels. Upload limits can lower the 5 MiB byte and 16 million pixel ceilings. The pixel check runs after browser decoding; hosts handling untrusted files should enforce media limits before serving them.

Asynchronous image exports reject after 15 seconds if an image has not loaded. Set `imageTimeoutMs` in export options to a positive value up to 120000 milliseconds. A timeout removes that export's image listener, so a late load does not complete the failed export.

The Yjs adapter validates peer records before rendering. Invalid records and records whose IDs disagree with their map keys stay in the shared document but are excluded from the view until repaired. The view is limited to 10000 valid objects. These checks do not authorize peer writes or limit the size of incoming Yjs updates: enforce permissions, document/update quotas and persistence limits in the host. Direct controlled element props are trusted application input; validate external snapshots with `deserializeBoard`.

Rough strokes cap interpolation work independently of coordinate distance, with a shared budget per polyline. Shape-label wrapping measures words once instead of repeatedly measuring a growing line. These bounds prevent the reproduced amplification cases; they are not a general large-board performance guarantee.

### Host storage admission

Use `acceptElementsChange(next, previous)` to enforce a host's serialized storage
budget before a local change reaches the board state or `onElementsChange`.
Return false and show a host error when the change is too large. Keep this
callback synchronous and pure apart from reporting that error. Remote controlled
props still come from the host's already validated authoritative state.

`maxImageBytes` limits each uploaded file; it does not limit the total board.
For a 1 MiB backend limit, reserve space for session metadata when checking
`new TextEncoder().encode(JSON.stringify({ elements: next, viewport })).length`.

Use `ref.current.getViewport()` to read `{ panX, panY, zoom }` for presence overlays. It returns a fresh navigation object without cloning board elements; `getSession()` still returns the full export snapshot. Host applications should keep each participant's viewport local unless following is explicitly requested.
